class NoAmmunitionError(Exception):
    pass


class OutOfRangeError(Exception):
    pass


class DestroyedError(Exception):
    pass


class GameFullError(Exception):
    pass


class GameNotFoundError(Exception):
    pass
